import React, { useState, useEffect } from "react";
import { Navbar, Nav, Container } from "react-bootstrap";
import ThemeToggle from "./ThemeToggle.jsx";

function NavigationBar() {
    const [activeSection, setActiveSection] = useState("home");

    const scrollTo = (id) => {
        const el = document.getElementById(id);
        if (el) {
            el.scrollIntoView({ behavior: "smooth" });
            setActiveSection(id);
        }
    };

    const navItems = [
        { id: "home", label: "Home" },
        { id: "about", label: "About" },
        { id: "projects", label: "Projects" },
        { id: "contact", label: "Contact" }
    ];

    // Handle scroll to update active section
    useEffect(() => {
        const handleScroll = () => {
            const sections = navItems.map(item => document.getElementById(item.id));
            const scrollPos = window.scrollY + 100;

            for (let i = sections.length - 1; i >= 0; i--) {
                if (sections[i] && sections[i].offsetTop <= scrollPos) {
                    setActiveSection(navItems[i].id);
                    break;
                }
            }
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <Navbar expand="lg" fixed="top" className="modern-navbar">
            <Container>
                <Navbar.Brand className="brand-text">
                    Daniel Nedyalkov
                </Navbar.Brand>
                
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="ms-auto d-flex align-items-center gap-3">
                        {navItems.map((item) => (
                            <Nav.Link
                                key={item.id}
                                onClick={() => scrollTo(item.id)}
                                className={`nav-pill ${activeSection === item.id ? 'active' : ''}`}
                            >
                                {item.label}
                            </Nav.Link>
                        ))}
                        <ThemeToggle />
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
}

export default NavigationBar;