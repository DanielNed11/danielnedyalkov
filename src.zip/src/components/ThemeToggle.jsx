import { useEffect, useState } from "react";

function ThemeToggle() {
    const [theme, setTheme] = useState(() =>
        window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
    );

    useEffect(() => {
        document.documentElement.setAttribute("data-theme", theme);
    }, [theme]);

    const toggleTheme = () => setTheme(theme === "light" ? "dark" : "light");

    return (
        <div className="theme-toggle" onClick={toggleTheme}>
            <div className={`toggle-circle ${theme}`}></div>
            <span className="icon">{theme === "light" ? "🌞" : "🌙"}</span>
        </div>
    );
}

export default ThemeToggle;
